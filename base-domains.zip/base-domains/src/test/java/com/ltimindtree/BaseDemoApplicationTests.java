package com.ltimindtree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaseDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
